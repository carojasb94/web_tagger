# -*- coding: utf-8 -*-

import sys
import funciones


#############################################################################
#############		 						#############
#############			  P R O G R A M A 			#############
#############							#############
#############################################################################



if len(sys.argv) == 4: #es un arreglo comienza por cero
						#[0] nombre del programa
						#[1] ruta del archivo.txt
						#[2] nombre del archivo con el que se va a gurardar el documento (ruta)
						#[3] ruta del programa
	
	arch = open (sys.argv[1], "r")
	text =arch.readlines()
	arch.close()
	
	ruta  = sys.argv[3]
	ruta  = ruta

	texto = funciones.acomodaTexto(text, ruta)
	texto = funciones.marcarConsiderandos(texto)
	texto = funciones.limpiarTexto(texto)	
	texto = funciones.restaurarNumeros(texto)

	arch = open (sys.argv[2], "w")
	arch.write(texto)
	arch.close()	  	
	
else:
	print "Error al tratar el archivo x"
